//function to filter all the records on 
//basis of recordId, barcode, warehouse name


function filterFunction() {
  var  inputField, input, filter, table, tr, td, i;
  inputField = document.getElementById("myField").value;
  input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("recordTable");
    tr = table.getElementsByTagName("tr");  
    for (i = 0; i < tr.length; i++) {
        if(inputField == 1)
        td = tr[i].getElementsByTagName("td")[1];
       else if(inputField == 2)
         td = tr[i].getElementsByTagName("td")[2];
        else
        td = tr[i].getElementsByTagName("td")[5];

         if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
    }
}