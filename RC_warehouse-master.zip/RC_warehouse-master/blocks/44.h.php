<?php
         
        $id = $_GET['rId'];
        $condition='';
        if(isset($_POST['StartDate']) || isset($_POST['EndDate']))
        {   
            $StartDate =strtotime($_POST['StartDate']);

            $EndDate= strtotime($_POST['EndDate']);
           
           if(!empty($_POST['StartDate']) && empty($_POST['EndDate']))
            {
               
               $condition = ' StartDate='.$StartDate;
               


            }
            elseif (empty($_POST['StartDate']) && !empty($_POST['EndDate']))
            {
	            
	            $condition = ' EndDate='.$EndDate;
                        	
            }
            else
            {
            $condition = ' StartDate='.$StartDate.' , EndDate = '. $EndDate;
          
            }
            $query = "Update records set".$condition." where ID =".$id;
            sqlsrv_query($connection, $query);
            $condition='';

        }

    ?>