<div class="column60">
    <div class="contentblock">
        <?php $form->displayForm('Update Password'); ?>
    </div>
</div>
