<div class="column60">
    <div class="contentblock">
        <?php $form->displayForm('Add Property'); ?>
    </div>
</div>
