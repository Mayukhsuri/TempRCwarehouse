<div class="column80">
    <div class="contentblock" style="padding: 0;  border-color: #000;  box-shadow: 0 0 5px 0 #555;">
        <img src="img/title_e2_med.jpg" style="border: none; margin: 0; padding: 0; width: 100%;"></img>
    </div>
</div>
