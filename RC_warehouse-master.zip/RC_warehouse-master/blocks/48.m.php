<div class="column60">
    <div class="contentblock">
        <?php
         echo '<h2>Generate Box PickUp Request</h2>' . PHP_EOL;
         echo '<div class="spacer"></div>' . PHP_EOL;
         echo 'Select the checkboxes to generate pickup requests.' . PHP_EOL;
         echo '<div class="spacer"></div>' . PHP_EOL;
         $query ="SELECT ID, RequestTime, DeliverTo, Location, CheckInRequest, NewStatus=(CASE [Status] WHEN 0 THEN 'On hold' 
					 WHEN 1 THEN 'Requested (Standard)'
					 WHEN 2 THEN 'Requested (Urgent)'
					 WHEN 3 THEN 'Pulling Boxes'
					 WHEN 4 THEN 'En-Route / Delivering'
					 WHEN 7 THEN 'Delivered'
					 WHEN 8 THEN 'Return Requested'
					 WHEN 9 THEN 'Complete'
					 ELSE 'Canceled' 
					 END)
					 FROM requests where RequestedBy = ".$_SESSION['rcw_currentUserID'];

	        $result = sqlsrv_query($connection, $query);
         	$row = sqlsrv_fetch_array($result);
			
        if(!empty($row)) {
            echo '<form method="POST" action="">';
            echo '<input type="submit" value= "Generate Pick Up Request" />';
             echo '<table>' . PHP_EOL;
             echo '<tr>' . PHP_EOL;
             echo '<th></th>' . PHP_EOL;
             echo '<th>Request ID</th>' . PHP_EOL;
             echo '<th>Request Time</th>' . PHP_EOL;
             echo '<th>Deliver To</th>' . PHP_EOL;
             echo '<th>Location</th>' . PHP_EOL;
             echo '<th>Status</th>' . PHP_EOL;
             echo '</tr>' . PHP_EOL;
             $resultcount = 0;
        	 while($row = sqlsrv_fetch_array($result))
        	 {
        	 	$resultcount++;
                    if(($resultcount / 2) == intval($resultcount / 2)) {$classname = ' class="alt"'; } else {$classname = ''; }
                    if($row['CheckInRequest'] == 0) {$boxProperty='';}else {$boxProperty='disabled';}
                     echo'<tr'. $classname. '>' . PHP_EOL;
                     echo '<td><input type="checkbox" name="pickup[]" value="'.$row['ID'].'"'. $boxProperty.'></td>';
                     echo'<td>'.$row['ID'].'</td>'. PHP_EOL;
                     echo'<td>'.date('m/d/Y', $row['RequestTime']).'</td>'. PHP_EOL;
                     echo'<td>'.$row['DeliverTo'].'</td>'. PHP_EOL;
                     echo'<td>'.$row['Location'].'</td>'. PHP_EOL;
                     echo'<td>'.$row['NewStatus'].'</td>'. PHP_EOL;
        	 }
        	 echo "</table>";
            }
            else
            {
            	echo "No box delivery request was made by you.";
            }
         ?>
          </div>
            </div>