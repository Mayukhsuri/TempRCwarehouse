<div class="column60">
    <div class="contentblock">
        <?php
            
            $form->displayForm('Search');
            
        ?>
    </div>
</div>
