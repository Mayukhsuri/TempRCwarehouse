<div class="column80">
    <div class="contentblock">
<?php
	
        $id = $_GET['rId'];

 echo '<h2>Change the Dates</h2>' . PHP_EOL;
            echo '<div class="spacer"></div>' . PHP_EOL;
echo '<form method="POST" action="">';

echo'<div> Start Date: <input type = "date" name = "StartDate" format="mm/dd/yyyy" /></div><br>';
echo'<div> End Date &nbsp;:&nbsp;<input type = "date" name = "EndDate" /></div><br>';
echo'<input type="submit" value= "Change Dates" />';
echo'</form>';
echo '<div class="linklist">' . PHP_EOL;
echo'<a href="index.php?pid=76">Reprint Box Label</a></div>';
?>
    </div>
</div>