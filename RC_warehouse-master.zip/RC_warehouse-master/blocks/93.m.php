<div class="column80">
    <div class="contentblock">
        <?php $form->displayForm('Update Group'); ?>
    </div>
</div>
