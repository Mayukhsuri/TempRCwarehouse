<?php
if(isset($_POST['pickup']))
{
	$ids = $_POST['pickup'];
	array_walk($ids, function(&$value, $key) {
    $value = (int)$value;
	});

	$ids = implode(', ', $ids);

	$query = "update requests set CheckInRequest =1, status = 8 where ID in($ids);";
	sqlsrv_query($connection, $query);
	echo'<script>
	alert("Request for pickup is under process.ThankYou!");
	</script>';
	
}
?>