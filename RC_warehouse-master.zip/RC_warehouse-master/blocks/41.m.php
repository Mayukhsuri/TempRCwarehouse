<div class="column60">
    <div class="contentblock">
        <?php $form->displayForm('Create Box'); ?>
    </div>
</div>
