<div class="column60">
    <div class="contentblock">
        <?php
         echo '<h2>All Records</h2>' . PHP_EOL;
         echo '<div class="spacer"></div>' . PHP_EOL;
         $sql= "SELECT r.ID as ID, r.DestructionDate as DESTRUCTIONDATE, b.Barcode as BARCODE, r.StartDate as STARTDATE, r.EndDate as ENDDATE , w.Name as WAREHOUSENAME, l.Row as ROW, l.Bay as BAY , l.Shelf as SHELF from records r, boxes b, locations l, warehouses w where r.BoxID = b.ID AND b.LocationID = l.ID AND l.Warehouse=w.ID ORDER BY r.ID";
         	$result = sqlsrv_query($connection, $sql);
         	$row = sqlsrv_fetch_array($result);
         	 echo 'Search Records By: &nbsp;' . PHP_EOL;
         	 echo '<select id="myField" name= "myField">
         		<option value="1">Record ID</option>
         		<option value="2">Barcode</option>
         		<option value="3">Warehouse Name</option>
         	</select>';
         	 echo '&nbsp; Value:' . PHP_EOL;
			echo'<input type="text" id="myInput" onkeyup="filterFunction()" placeholder="Search for...."> ';
			echo '<form method="POST" action="exportexcel.php">';
			echo '<input type="submit" value= "Export to Excel" />';
         	if(!empty($row))
         	{
         		
        		echo'<table id="recordTable">' . PHP_EOL;
                echo '<tr>' . PHP_EOL;
                echo '<th></th>' . PHP_EOL;
                echo '<th>Record ID</th>' . PHP_EOL;
                echo '<th>Barcode</th>' . PHP_EOL;
                echo '<th>Start Date</th>' . PHP_EOL;
                echo '<th>End Date</th>' . PHP_EOL;
                echo '<th>Warehouse Name</th>' . PHP_EOL;
                echo '<th>Row</th>' . PHP_EOL;
                echo '<th>Bay</th>' . PHP_EOL;
                echo '<th>Shelf</th>' . PHP_EOL;
                echo '</tr>' . PHP_EOL;
                $resultcount=0;
                 while($row = sqlsrv_fetch_array($result)) {
                 	$resultcount++;
                    if(($resultcount / 2) == intval($resultcount / 2)) {$classname = ' class="alt"'; } else {$classname = ''; }
                    if($row['DESTRUCTIONDATE']<= time()){$boxProperty='';}else {$boxProperty='disabled';}
                    echo'<tr'. $classname. '>' . PHP_EOL;
                    echo '<td><input type="checkbox" name="xport[]" value="'.$row['ID'].'"'. $boxProperty.'></td>';
                    echo'<td>'.$row['ID'].'</td>'. PHP_EOL;
                    echo'<td>'.$row['BARCODE'].'</td>'. PHP_EOL;
                    echo'<td>'.date('m/d/Y', $row['STARTDATE']).'</td>'. PHP_EOL;
                    echo'<td>'.date('m/d/Y', $row['ENDDATE']).'</td>'. PHP_EOL;
                    echo'<td>'.$row['WAREHOUSENAME'].'</td>'. PHP_EOL;
                    echo'<td>'.$row['ROW'].'</td>'. PHP_EOL;
                    echo'<td>'.$row['BAY'].'</td>'. PHP_EOL;
                    echo'<td>'.$row['SHELF'].'</td>'. PHP_EOL; 
                   	echo '</tr>' . PHP_EOL;
                   }
                   echo '</table>' . PHP_EOL;
               }
             else  
                    {
                    	echo "No record Found";
                    }
                    ?>
                </div>
            </div>