<div class="column60">
    <div class="contentblock">
        <?php
write_log(__FILE__,__LINE__);
            
            $form->displayForm('Search');
            
        ?>
    </div>
</div>
