<?php

   
    $bigpepper = "25uoli1gIckxxO02887xwQprnzEEd5Yu";

    define("DBSERVER","devwsql2");
    define("DBNAME","RCWarehouse");
?>
