<?php

    $bigpepper = "25uoli1gIckxxO02887xwQprnzEEd5Yu";

    define("dbserver","localhost");
    define("dbusername","root");
    define("dbpassword","i2IdI8QpTLTg");
    define("dbname","BoxWarehouse");

?>
