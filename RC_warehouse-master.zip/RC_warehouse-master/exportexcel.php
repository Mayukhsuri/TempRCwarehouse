<?php

 
session_start();
require_once('includes/settings.php'); 
require_once('includes/g1functions.php');
require_once('includes/connection.php');

write_log(__FILE__,__LINE__);
/*
Expecting $_POST['xport'] array of row ids
*/
if( !isset($_POST['xport']) OR !is_array($_POST['xport']) ) {
    exit('No rows selected for export');
}

$ids = $_POST['xport'];
array_walk($ids, function(&$value, $key) {
    $value = (int)$value;
});
$ids = implode(', ', $ids);

$filename = "Record_export_".date('D, d M Y H:i:s') . ".xls";
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=\"$filename\"");
$show_coloumn = false;

$query="SELECT r.ID as ID, b.Barcode as BARCODE, r.StartDate as STARTDATE, r.EndDate as ENDDATE , w.Name as WAREHOUSENAME, l.Row as ROW, l.Bay as BAY , l.Shelf as SHELF from records r, boxes b, locations l, warehouses w where r.BoxID = b.ID AND b.LocationID = l.ID AND l.Warehouse=w.ID and r.ID in($ids)";
			$result = sqlsrv_query($connection, $query);
         	while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC))
         	{
         		if(!$show_coloumn)
         		{
         			echo implode("\t", array_keys($row)) . "\n";
         			$show_coloumn = true;
         		}
         			$row['STARTDATE'] = date('m/d/Y', $row['STARTDATE']);
         			$row['ENDDATE'] = date('m/d/Y', $row['ENDDATE']);
         			
         			echo implode("\t", array_values($row)) . "\n";
         		}
?>